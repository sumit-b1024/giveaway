// tokenBlacklist.js
const tokenBlacklist = new Set();

module.exports = tokenBlacklist;