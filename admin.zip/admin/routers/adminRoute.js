const express = require("express");
var bodyParser = require("body-parser");
var urlencodeParser = bodyParser.urlencoded({ extended: false });

const {
    getAllAdmins,
    addAdmin,
    insertAdmin,
    editAdmin,
    updateAdmin,
    deleteAdmin,
    statusAdmin,
    profileAdmin,
    updateProfileAdmin,
    changePasswordAdmin,
    updatePasswordAdmin

} = require("../controllers/admin/AdminController");

const {adminupload} = require("../middeleware/imageUpload")

const router = express.Router();

router.get("/admin/admins", getAllAdmins);

router.get("/admin/admins/create", addAdmin);

router.post(
    "/admin/admins/save",
    adminupload.fields([
      {
        name: "admin_image",
        maxCount: 1,
      }
    ]),
    insertAdmin
  );

router.get("/admin/admins/edit/:id", editAdmin);

router.post(
    "/admin/admins/update",
    adminupload.fields([
      {
        name: "admin_image",
        maxCount: 1,
      }
    ]),
    updateAdmin
  );

router.get("/admin/admins/delete/:id", deleteAdmin);

router.get("/admin/admins/status/:id/:status", statusAdmin);

router.get("/admin/profile", profileAdmin);

router.post(
    "/admin/update-profile",
    adminupload.fields([
      {
        name: "admin_image",
        maxCount: 1,
      }
    ]),
    updateProfileAdmin
);

router.get("/admin/change-password", changePasswordAdmin);

router.post("/admin/update-password", urlencodeParser, updatePasswordAdmin);


module.exports = router;