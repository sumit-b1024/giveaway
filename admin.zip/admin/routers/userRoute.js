var express = require("express");
var bodyParser = require("body-parser");
var urlencodeParser = bodyParser.urlencoded({ extended: false });

const {noupload, userupload} = require("../middeleware/imageUpload");
const verifyToken = require('../middeleware/verifyToken');

const {
    getAllUsers,
    addUser,
    insertUser,
    editUser,
    updateUser,
    deleteUser,
    statusUser

} = require("../controllers/admin/UserController");

const {
  apiCreateUser,
  apiUpdate,
  apiDelete,
  apiAllUsers,
  apiFindUser,
  apiUserBySearch,
  apiLogin,
  apiLogout,
  apiChangePassword

} = require("../controllers/api/UserController");


const router = express.Router();


/*---------- WEB Routes  -------------*/

router.get("/admin/users", getAllUsers);

router.get("/admin/user/create", addUser);

router.post(
    "/admin/user/save",
    userupload.fields([
      {
        name: "profile_image",
        maxCount: 1,
      },
      {
        name: "banner_image",
        maxCount: 1,
      },
    ]),
    insertUser
  );

  router.get("/admin/user/edit/:id", editUser);

  router.post(
    "/admin/user/update",
    userupload.fields([
      {
        name: "banner_image",
        maxCount: 1,
      },
      {
        name: "profile_image",
        maxCount: 1,
      },
    ]),
    updateUser
  );

router.get("/admin/user/delete/:id", deleteUser);

router.get("/admin/user/status/:id/:status", statusUser);


/*---------- API Routes  -------------*/
router.post(
  "/api/V1/user/create",
  userupload.fields([
    {
      name: "banner_image",
      maxCount: 1,
    },
    {
      name: "profile_image",
      maxCount: 1,
    },
  ]),
  verifyToken,
  apiCreateUser
);
router.post(
  "/api/V1/user/update/:id",
  userupload.fields([
    {
      name: "banner_image",
      maxCount: 1,
    },
    {
      name: "profile_image",
      maxCount: 1,
    },
  ]),
  verifyToken,
  apiUpdate
);
router.delete("/api/V1/deleteuser/:id", verifyToken, apiDelete);
router.get("/api/V1/allusers", verifyToken, apiAllUsers);
router.get("/api/V1/user/:id", verifyToken, apiFindUser);
router.post("/api/V1/usersearch", verifyToken, apiUserBySearch);



//router.get("/api/V1/user/:id/verify/:token", apiVerifyuser);

module.exports = router;