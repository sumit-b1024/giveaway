/*
Template Name: Swapp - Admin
Author: Themesbrand
Website: https://Themesbrand.com/
Contact: Themesbrand@gmail.com
File: lightbox Js File
*/


// GLightbox Popup

var lightbox = GLightbox({
    selector: '.image-popup',
    title: false,
});


// GLightbox Popup

var lightboxDesc = GLightbox({
    selector: '.image-popup-desc',
});

// GLightbox Popup

var lightboxvideo = GLightbox({
    selector: '.image-popup-video-map',
    title: false,
});